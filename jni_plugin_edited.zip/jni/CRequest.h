//
// Created by Zhasulan on 14.07.2024.
//

// #ifndef KOLSON_MENU_CREQUEST_H
// #define KOLSON_MENU_CREQUEST_H


// class CRequest {

// public:
//     size_t WriteCallback(void* contents, size_t size, size_t nmemb, void* userp);
//     bool isCorrectKey(std::string key);
// };


// #endif //KOLSON_MENU_CREQUEST_H
