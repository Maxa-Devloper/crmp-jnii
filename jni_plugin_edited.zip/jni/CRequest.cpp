//
// Created by Zhasulan on 14.07.2024.
//

// #include "CRequest.h"
// #include "main.h"
// #include "../vendor/curl/include/curl/curl.h"

// size_t CRequest::WriteCallback(void* contents, size_t size, size_t nmemb, void* userp) {
//     ((std::string*)userp)->append((char*)contents, size * nmemb);
//     return size * nmemb;
// }

// bool CRequest::isCorrectKey(std::string key)
// {
//     CURL *curl;
//     CURLcode res;
//     std::string readBuffer;

//     curl_global_init(CURL_GLOBAL_DEFAULT);
//     curl = curl_easy_init();

//     if (curl) {
//         const std::string url = OBFUSCATE("https://example.com/api/endpoint");

//         const std::string jsonData;
//         sprintf(jsonData, OBFUSCATE("{\"key\": \"%s\"}"), key);

//         // Установка URL
//         curl_easy_setopt(curl, CURLOPT_URL, url.c_str());

//         // Установка заголовков
//         struct curl_slist *headers = nullptr;
//         headers = curl_slist_append(headers, OBFUSCATE("Content-Type: application/json"));
//         curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);

//         // Установка данных для запроса
//         curl_easy_setopt(curl, CURLOPT_POSTFIELDS, jsonData.c_str());

//         // Установка функции обратного вызова для записи данных
//         curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteCallback);
//         curl_easy_setopt(curl, CURLOPT_WRITEDATA, &readBuffer);

//         // Выполнение запроса
//         res = curl_easy_perform(curl);

//         // Проверка на ошибки
//         if (res != CURLE_OK) {
//             fprintf(stderr, "curl_easy_perform() failed: %s\n", curl_easy_strerror(res));
//         } else {
//             std::cout << "Response Data: " << readBuffer << std::endl;
//         }

//         // Очистка
//         curl_slist_free_all(headers);
//         curl_easy_cleanup(curl);
//     }

//     curl_global_cleanup();
//     return 0;
// }
