#include "main.h"
#include "audiostream.h"
#include "netgame.h"
#include "CKeyBoard.h"
#include "CLoadPresets.h"
#include "utils/Utils.h"

void(*old_CKeyBoard_ChatHandle)(const char* str);
void CKeyBoard_ChatHandle(const char* str)
{
    std::string inputCommand(str);

	inputCommand.erase(inputCommand.begin(), std::find_if(inputCommand.begin(), inputCommand.end(), [](int ch) {
        return !std::isspace(ch);
    }));
    inputCommand.erase(std::find_if(inputCommand.rbegin(), inputCommand.rend(), [](int ch) {
        return !std::isspace(ch);
    }).base(), inputCommand.end());
	
    std::transform(inputCommand.begin(), inputCommand.end(), inputCommand.begin(), ::tolower);

    std::string shortCommand;
    std::string args;
    size_t spacePos = inputCommand.find(' ');
    if (spacePos != std::string::npos) {
        shortCommand = inputCommand.substr(0, spacePos);
        args = inputCommand.substr(spacePos);
    } else {
        shortCommand = inputCommand;
    }
    
    auto it = CLoadPresets::commandMap.find(shortCommand);
    if (it != CLoadPresets::commandMap.end()) 
    {        
        std::string normalCmd = it->second + args;
        CNetGame::SendChatCommand(normalCmd.c_str());
        CKeyBoard::Close();
        return;
    }
	return old_CKeyBoard_ChatHandle(str);
}

void(*old_CNetGame_Initialise)();
void CNetGame_Initialise()
{
    CNetGame::AddDebugMessage(OBFUSCATE("{FFCC00}Loaded ZAMENA-Plugin by @mtadev "));
    return old_CNetGame_Initialise();
}



void InstallGlobalHooks() {
    MSHookFunction((void*)(gameAddr + ADDR_CKEYBOARD_CHATHANDLE + 1), (void*)CKeyBoard_ChatHandle, (void**)&old_CKeyBoard_ChatHandle);
    MSHookFunction((void*)(gameAddr + ADDR_CNETGAME_INITIALISE + 1), (void*)CNetGame_Initialise, (void**)&old_CNetGame_Initialise);
}
