#include "main.h"
#include "CKeyBoard.h"

void CKeyBoard::Close()
{
	return (( void (*)())(gameAddr + ADDR_CKEYBOARD_CLOSE + 1))();
}