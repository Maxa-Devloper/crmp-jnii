#ifndef _KEYBOARD_H_
#define _KEYBOARD_H_

class CKeyBoard
{
private:
    /* data */
public:
    static void Close();
};


#endif /* _KEYBOARD_H_ */