#include "main.h"
#include "utils/Utils.h"
#include "CLoadPresets.h"

uintptr_t gameAddr = 0;
char *g_pszStorage = nullptr;

void InstallGlobalHooks();

void *hack_thread(void *) 
{
    do {
        sleep(1);
    } while (!Utils::isLibraryLoaded(OBFUSCATE("libblackrussia-client.so")));
    gameAddr = Utils::findLibrary(OBFUSCATE("libblackrussia-client.so"));
    
    if (!gameAddr) {
        Log::fprint(OBFUSCATE("Failed to find game address!"));
        std::terminate();
    }

    do {
        sleep(1);
    } while (!Utils::isLibraryLoaded(OBFUSCATE("libip.so")));
    
    g_pszStorage = (char*)(gameAddr + STORAGE);

	if(!g_pszStorage)
	{
		Log::fprint(OBFUSCATE("Error: storage path not found!"));
		std::terminate();
	}
    
    Log::fprint(OBFUSCATE("Storage: %s"), g_pszStorage);
    Log::fprint(OBFUSCATE("Zamena IP @mtadev"));

    CLoadPresets::LoadPresets();

    // анти-штраф
    Utils::makeNOP(gameAddr + ANTI_SHTRAF_1, 2);
    Utils::makeNOP(gameAddr + ANTI_SHTRAF_2, 2);

    // Бесконечный бег
    Utils::makeNOP(gameAddr + FREE_SPRINT_1, 2);
    Utils::makeNOP(gameAddr + FREE_SPRINT_2, 2);
    
	InstallGlobalHooks();
    
    pthread_exit(nullptr);
    return nullptr;
}

extern "C" JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM *vm, void *reserved) 
{
    JNIEnv *globalEnv;
    vm->GetEnv((void **) &globalEnv, JNI_VERSION_1_6);
    
	pthread_t ptid;
    pthread_create(&ptid, NULL, hack_thread, NULL);

    return JNI_VERSION_1_6;
}
