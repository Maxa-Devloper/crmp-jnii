
/* (c) 2024 Kolson */

#include <stdio.h>
#include <assert.h>
#include <iostream>
#include <fstream>
#include <sys/stat.h>
#include "main.h"
#include "CLoadPresets.h"
#include "vendor/json/single_include//nlohmann/json.hpp"

using json = nlohmann::json;

std::unordered_map<std::string, std::string> CLoadPresets::commandMap;

void CLoadPresets::LoadPresets()
{
    const char* filePath = OBFUSCATE("/storage/emulated/0/Android/data/com.br.top/kolson/short_commands.json");
    const char* folderPath = OBFUSCATE("/storage/emulated/0/Android/data/com.br.top/kolson");
    
    struct stat info;
    if (stat(folderPath, &info) != 0) {
        if (mkdir(folderPath, 0777) == -1) {
            Log::fprint(OBFUSCATE("Unable to create folder: %s"), folderPath);
            return;
        }
    }
    
    std::ifstream file(filePath);
    if (!file.is_open()) 
    {
        std::ofstream newFile(filePath);
        if (!newFile.is_open()) 
        {
            Log::fprint(OBFUSCATE("Unable to create file: %s"), filePath);
            return;
        }

        json initialCommands = json::array({
            { {"normal", "/buyhouse"}, {"short", "/bh"} },
            { {"normal", "/famsklad"}, {"short", "/fs"} },
            { {"normal", "/garage"}, {"short", "/gr"} },
            { {"normal", "/changeprop"}, {"short", "/cp"} },
            { {"normal", "/gevent"}, {"short", "/gv"} },
            { {"normal", "/donate"}, {"short", "/don"} },
            { {"normal", "/fammute"}, {"short", "/fmute"} },
            { {"normal", "/unfammute"}, {"short", "/unfmute"} },
            { {"normal", "/cameditgui"}, {"short", "/ceg"} }
        });

        newFile << initialCommands.dump(4);
        newFile.close();
    }

    json jsonData;
    file >> jsonData;

    int i = 0;
    for (const auto& item : jsonData) {
        std::string normalCmd = item.at(OBFUSCATE("normal")).get<std::string>();
        std::string shortCmd = item.at(OBFUSCATE("short")).get<std::string>();

        std::transform(normalCmd.begin(), normalCmd.end(), normalCmd.begin(), ::tolower);
        std::transform(shortCmd.begin(), shortCmd.end(), shortCmd.begin(), ::tolower);

        commandMap[shortCmd] = normalCmd;
    }
    file.close();
    Log::fprint(OBFUSCATE("Pressets Loaded"));

    return;
}
