/* (c) 2024 Kolson */

#include <pthread.h>
#include <mutex>
#include <chrono>
#include <thread>

#include "main.h"
#include "audio/bass.h"
#include "audiostream.h"

CAudioStream::CAudioStream()
{
	m_strAudioStreamFile.clear();

	m_bassStreamSample = NULL;

	m_bPlaying = false;
	m_bPaused = false;
}

CAudioStream::~CAudioStream()
{
	if (m_bPlaying) Stop();
	m_strAudioStreamFile.clear();
}

bool CAudioStream::PlayByFile(const char* filepath)
{
	if (m_bPlaying && m_bassStreamSample)
	{
		if (!Stop())
			return false;
	}

	m_strAudioStreamFile = filepath;

	m_bPaused = false;

    m_bassStreamSample = BASS_StreamCreateFile(false, m_strAudioStreamFile.c_str(), 0, 0, 0);
	if (m_bassStreamSample)
	{
        BASS_ChannelPlay(m_bassStreamSample, false);
		m_bPlaying = true;
	}

	return true;
}

bool CAudioStream::Stop()
{
	if (m_bPlaying && m_bassStreamSample)
	{
		BASS_StreamFree(m_bassStreamSample);
		m_bassStreamSample = NULL;
		m_bPlaying = false;
	}
	return true;
}