
#ifndef _NETGAME_H_
#define _NETGAME_H_

class CNetGame
{
private:

public:
    static void SendChatCommand(const char* szCommand);
    static void AddDebugMessage(const char* szFormat, ...);
};


#endif // !_NETGAME_H_