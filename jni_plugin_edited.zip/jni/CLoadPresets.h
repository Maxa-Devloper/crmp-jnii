#ifndef _LOADPRESETS_H_
#define _LOADPRESETS_H_

#include <unordered_map>

#define MAX_PRESETS 100


struct Command {
    std::string normal;
    std::string shortCommand;
};


class CLoadPresets
{
public:
    static void LoadPresets();
public:
    static std::unordered_map<std::string, std::string> commandMap;
};


#endif /* _LOADPRESETS_H_ */