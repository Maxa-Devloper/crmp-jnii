#include "main.h"
#include "utils/Utils.h"
#include "netgame.h"
#define SEND_RPC(networkObject, functionName, packet) { int rpcid = (RPC_##functionName); (networkObject)->RPC(&rpcid, &packet, HIGH_PRIORITY, RELIABLE, 0, FALSE, UNASSIGNED_NETWORK_ID, NULL); }
#include <stdlib.h>
#include <sstream>
#include "obfuscate/str_obfuscate.hpp"

CNetGame* CNetGame::m_SingletonInstance = nullptr;
char* CNetGame::m_szHostOrIp;
bool CNetGame::bConnected = false;

CNetGame::~CNetGame()
{
    RakNetworkFactory::DestroyRakClientInterface(m_rakClientInterface);
}

void CNetGame::SendChatCommand(const char* szCommand)
{
	return (( void (*)(const char*))(gameAddr + ADDR_CNETGAME_SENDCHATCOMMAND + 1))(szCommand);
}

void CNetGame::Packet_AUTH_KEY(Packet *p)
{
    RakNet::BitStream bsAuth((unsigned char *)p->data, p->length, false);

    uint8_t byteAuthLen;
    char szAuth[260];

    bsAuth.IgnoreBits(8);
    bsAuth.Read(byteAuthLen);
    bsAuth.Read(szAuth, byteAuthLen);
    szAuth[byteAuthLen] = '\0';

    char szAuthKey[260];
    gen_auth_key(szAuthKey, szAuth);

    RakNet::BitStream bsKey;
    uint8_t byteAuthKeyLen = (uint8_t)strlen(szAuthKey);

    bsKey.Write((uint8_t)ID_AUTH_KEY);
    bsKey.Write((uint8_t)byteAuthKeyLen);
    bsKey.Write(szAuthKey, byteAuthKeyLen);
    m_rakClientInterface->Send(&bsKey, SYSTEM_PRIORITY, RELIABLE, 0);

    LOG(OBFUSCATE("AUTH_KEY IN = %s; OUT = %s"), (char*) (p->data + 2), szAuthKey);
}

void CNetGame::Process()
{
    Packet* pPacket = 0;
    while((pPacket = m_rakClientInterface->Receive()))
    {
        int v9 = pPacket->data[0];
        LOG(OBFUSCATE("Packet received -> %d\n"), v9);

        switch(v9)
        {
            case ID_AUTH_KEY:
                LOG(OBFUSCATE("Incoming packet: ID_AUTH_KEY"));
                Packet_AUTH_KEY(pPacket);
                break;

            case ID_CONNECTION_ATTEMPT_FAILED:
                //pChatWindow->AddDebugMessageNonFormatted(CLocalisation::GetMessage(E_MSG::CONNECTION_ATTEMPT_FAILED));
                //SetGameState(GAMESTATE_WAIT_CONNECT);
                break;

            case ID_NO_FREE_INCOMING_CONNECTIONS:
                //pChatWindow->AddDebugMessageNonFormatted(CLocalisation::GetMessage(E_MSG::FULL_SERVER));
                //SetGameState(GAMESTATE_WAIT_CONNECT);
                break;

            case ID_DISCONNECTION_NOTIFICATION:
                break;

            case ID_CONNECTION_LOST:
                break;

            case ID_CONNECTION_REQUEST_ACCEPTED:
                CNetGame::bConnected = true;
                Packet_ConnectionSucceeded(pPacket);
                break;

            case ID_FAILED_INITIALIZE_ENCRIPTION:
                //pChatWindow->AddDebugMessage(OBFUSCATE("Failed to initialize encryption."));
                break;

                // fixed
            case ID_CONNECTION_BANNED:
                ////pChatWindow->AddDebugMessageNonFormatted(CLocalisation::GetMessage(E_MSG::BANNED));
                //SetGameState(GAMESTATE_WAIT_CONNECT);
                break;

            case ID_INVALID_PASSWORD:
                //pChatWindow->AddDebugMessage(OBFUSCATE("Incorrect Server Password."));
                m_rakClientInterface->Disconnect(0);
                break;

            case ID_PLAYER_SYNC:

                break;

            case ID_VEHICLE_SYNC:

                break;

            case ID_PASSENGER_SYNC:

                break;

            case ID_MARKERS_SYNC:

                break;

            case ID_AIM_SYNC:

                break;

            case ID_BULLET_SYNC:

                break;

            case ID_TRAILER_SYNC:

                break;

            case ID_CUSTOM_RPC:

                break;
        }

        m_rakClientInterface->DeallocatePacket(pPacket);
    }

    if (m_isInGame && iNetModeNormalOnfootSendRate > 0 && lastOnFootSyncTick < (GetTickCount() - iNetModeNormalOnfootSendRate))
    {

        lastOnFootSyncTick = GetTickCount();
    }
}

void CNetGame::Packet_ConnectionSucceeded(Packet* pkt)
{
    RakNet::BitStream bsSuccAuth((unsigned char *)pkt->data, pkt->length, false);
    unsigned short MyPlayerID;
    unsigned int uiChallenge;

    bsSuccAuth.IgnoreBits(8); // ID_CONNECTION_REQUEST_ACCEPTED
    bsSuccAuth.IgnoreBits(32); // binaryAddress
    bsSuccAuth.IgnoreBits(16); // port
    bsSuccAuth.Read(MyPlayerID);
    bsSuccAuth.Read(uiChallenge);
    char ip[0x7F];
    strncpy(ip, m_szHostOrIp, sizeof(ip));

    std::vector<std::string> strings;
    std::istringstream f((const char*)&ip[0]);
    std::string s;
    int sum = 0;
    while (getline(f, s, '.'))
    {
        sum += atoi(s.c_str());
    }


void CNetGame::DbgConnect()
{
	m_rakClientInterface->Connect((char*)OBFUSCATE("188.127.241.74"), 1959, 0, 0, 5);
	m_szHostOrIp = (char*)OBFUSCATE("188.127.241.74");
}

void CNetGame::AddDebugMessage(const char* szFormat, ...)
{
    char buffer[256];
    va_list args;
    va_start(args, szFormat);
    vsnprintf(buffer, sizeof(buffer), szFormat, args);
    va_end(args);

	return (( void (*)(const char*))(gameAddr + ADDR_CNETGAME_ADDDEBUGMESSAGE + 1))(buffer);	
}