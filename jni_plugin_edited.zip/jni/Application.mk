# To AIDE Users: If you are using 32-bit/ARMv7 phone, please remove arm64-v8a
APP_ABI := armeabi-v7a
APP_PLATFORM := android-21
APP_STL := c++_static
APP_OPTIM := release