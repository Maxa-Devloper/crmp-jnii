#pragma once
#ifndef _MAIN_H_
#define _MAIN_H_

#include <address_table_x32.h>

#include <list>
#include <vector>
#include <string.h>
#include <pthread.h>
#include <thread>
#include <cstring>
#include <jni.h>
#include <unistd.h>
#include <fstream>
#include <iostream>
#include <dlfcn.h>
#include <EGL/egl.h>
#include <GLES2/gl2.h>

#include "vendor/security/obfuscate.h"
#include "vendor/memory/Dobby/dobby.h"
#include "vendor/memory/Substrate/CydiaSubstrate.h"
#include "vendor/SimpleAndroidLog/log.h"
#include "common.h"

#endif
