LOCAL_PATH := $(call my-dir)

include $(CLEAR_VARS)
LOCAL_MODULE := libdobby
LOCAL_SRC_FILES := vendor/memory/Dobby/$(TARGET_ARCH_ABI)/libdobby.a
include $(PREBUILT_STATIC_LIBRARY)

include $(CLEAR_VARS)
LOCAL_MODULE    := libcurl
LOCAL_SRC_FILES := vendor/curl/libcurl.a

include $(PREBUILT_STATIC_LIBRARY)

include $(CLEAR_VARS)

APP_DEBUG := false
APP_OPTIM := release
LOCAL_MODULE := ip

# -std=c++17 is required to support AIDE app with NDK
LOCAL_CPPFLAGS := -w -s -Wno-error=format-security -fvisibility=hidden -std=c++17
LOCAL_CPPFLAGS += -fpermissive -fexceptions -O3 -frtti
LOCAL_LDLIBS := -lm -llog -lc -lz -ljnigraphics -landroid -lEGL -lGLESv2 -lGLESv3 -lGLESv1_CM  -lOpenSLES

LOCAL_STATIC_LIBRARIES := libdobby libcurl

LOCAL_C_INCLUDES += $(wildcard $(LOCAL_PATH)/vendor/)


FILE_LIST := $(wildcard $(LOCAL_PATH)/*.cpp)
FILE_LIST += $(wildcard $(LOCAL_PATH)/utils/*.cpp)

# vendor
FILE_LIST += $(wildcard $(LOCAL_PATH)/vendor/*/*.cpp)
FILE_LIST += $(wildcard $(LOCAL_PATH)/vendor/*/*/*.cpp)
FILE_LIST += $(wildcard $(LOCAL_PATH)/vendor/*/*/*/*.cpp)


# Here you add the cpp file to compile
LOCAL_SRC_FILES := $(FILE_LIST:$(LOCAL_PATH)/%=%)

include $(BUILD_SHARED_LIBRARY)