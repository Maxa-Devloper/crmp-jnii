#include <jni.h>
#include <unistd.h>
#include <cstdio>
#include <cstring>
#include <string>
#include <cstdlib>
#include <random>
#include <sys/mman.h>
#include "Utils.h"
#include "../vendor/security/obfuscate.h"

typedef unsigned long TWORD;
static uintptr_t libBase;
bool libLoaded = false;

TWORD Utils::findLibrary(const char *library) {
    char filename[0xFF] = {0},
            buffer[1024] = {0};
    FILE *fp = NULL;
    TWORD address = 0;

    sprintf(filename, OBFUSCATE("/proc/self/maps"));

    fp = fopen(filename, OBFUSCATE("rt"));
    if (fp == NULL) {
        perror(OBFUSCATE("fopen"));
        goto done;
    }

    while (fgets(buffer, sizeof(buffer), fp)) {
        if (strstr(buffer, library)) {
            address = (TWORD) strtoul(buffer, NULL, 16);
            goto done;
        }
    }

    done:

    if (fp) {
        fclose(fp);
    }

    return address;
}

TWORD Utils::getAbsoluteAddress(TWORD relativeAddrconst, const char *libraryName) {
    libBase = findLibrary(libraryName);
    if (libBase == 0)
        return 0;
    return (reinterpret_cast<TWORD>(libBase + relativeAddrconst));
}

TWORD Utils::getRealOffset(TWORD address) {
    if (libBase == 0) {
        //libBase = get_libBase(libName);
    }
    return (libBase + address);
}

jboolean Utils::isGameLibLoaded(JNIEnv *env, jobject thiz) {
    return libLoaded;
}

bool Utils::isLibraryLoaded(const char *libraryName) {
    //libLoaded = true;
    char line[512] = {0};
    FILE *fp = fopen(OBFUSCATE("/proc/self/maps"), OBFUSCATE("rt"));
    if (fp != NULL) {
        while (fgets(line, sizeof(line), fp)) {
            std::string a = line;
            if (strstr(line, libraryName)) {
                libLoaded = true;
                return true;
            }
        }
        fclose(fp);
    }
    return false;
}

uintptr_t Utils::str2offset(const char *c) {
    int base = 16;
    // See if this function catches all possibilities.
    // If it doesn't, the function would have to be amended
    // whenever you add a combination of architecture and
    // compiler that is not yet addressed.
    static_assert(sizeof(uintptr_t) == sizeof(unsigned long)
                  || sizeof(uintptr_t) == sizeof(unsigned long long),
                  "Please add string to handle conversion for this architecture.");

    // Now choose the correct function ...
    if (sizeof(uintptr_t) == sizeof(unsigned long)) {
        return strtoul(c, nullptr, base);
    }

    // All other options exhausted, sizeof(uintptr_t) == sizeof(unsigned long long))
    return strtoull(c, nullptr, base);
}

int Utils::randomX(int min, int max)
{
    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_int_distribution<> dis(min, max);

    int random_number = dis(gen);

    return random_number;
}

void Utils::unProtect(uintptr_t address, size_t size)
{
    if (size)
    {
        unsigned char* to_page = (unsigned char*)((unsigned int)(address) & 0xFFFFF000);
        size_t page_size = 0;


        for (int i = 0, j = 0; i < size; ++i)
        {
            page_size = j * 4096;
            if (&((unsigned char*)(address))[i] >= &to_page[page_size])
                ++j;
        }

        mprotect(to_page, page_size, PROT_READ | PROT_WRITE | PROT_EXEC);
        return;
    }
}


void Utils::FuckCode(uintptr_t ptr, size_t dwSize)
{
	if (dwSize)
	{
		auto* to_page = (unsigned char*)((unsigned int)(ptr) & 0xFFFFF000);
		size_t page_size = 0;

		for (int i = 0, j = 0; i < dwSize; ++i)
		{
			page_size = j * 4096;
			if (&((unsigned char*)(ptr))[i] >= &to_page[page_size])
				++j;
		}
		mprotect(to_page, page_size, PROT_READ | PROT_EXEC);
		return;
	}
}

void Utils::makeNOP(uintptr_t addr, unsigned int count)
{
	unProtect(addr);

    for(uintptr_t ptr = addr; ptr != (addr+(count*2)); ptr += 2)
    {
        *(char*)ptr = 0x00;
        *(char*)(ptr+1) = 0x46;
    }

    cacheflush(addr, (uintptr_t)(addr + count*2), 0);
}