#pragma once
#ifndef _UTILS_H_
#define _UTILS_H_

#include "../main.h"

typedef unsigned long TWORD;

#if defined(__aarch64__) 
    #define __64BIT
    #define cacheflush(c, n, zeroarg) __builtin___clear_cache((char*)(c), (char*)(n))
#endif


class Utils
{
public:

	static TWORD findLibrary(const char *library);
	static TWORD getAbsoluteAddress(TWORD relativeAddrconst, const char *libraryName = OBFUSCATE("libblackrussia-client.so"));
    static TWORD getRealOffset(TWORD address);
    static jboolean isGameLibLoaded(JNIEnv *env, jobject thiz);
    static bool isLibraryLoaded(const char *libraryName);
    static uintptr_t str2offset(const char *c);
    static int randomX(int min, int max);
    static void FuckCode(uintptr_t ptr, size_t dwSize = 100);

	static void unProtect(uintptr_t ptr, size_t size = 100);
	static void makeNOP(uintptr_t addr, unsigned int count);
};


#endif  
