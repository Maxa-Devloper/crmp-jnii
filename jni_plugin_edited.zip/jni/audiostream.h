#ifndef _AUDIOSTREAM_H_
#define _AUDIOSTREAM_H_

#include <atomic>
#include "audio/bass.h"
#include <string>

class CAudioStream
{
private:
	std::string					m_strAudioStreamFile;

	HSTREAM						m_bassStreamSample;

	bool						m_bPlaying;
	bool						m_bPaused;

public:
	CAudioStream();
	~CAudioStream();

	bool PlayByFile(const char* filepath);
	bool Stop();
	void Process();
};

#endif