#pragma once

#include <cstdint>

#ifndef _COMMON_H_
#define _COMMON_H_

extern uintptr_t gameAddr;
extern char* g_pszStorage;

#endif
