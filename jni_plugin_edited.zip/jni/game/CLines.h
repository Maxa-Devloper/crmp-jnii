#ifndef _LINES_H_
#define _LINES_H_

class CLines
{
public:
	static void RenderLineWithClipping(float x1, float y1, float z1, float x2, float y2, float z2, uint32 c1, uint32 c2);
};


#endif /* _LINES_H_ */