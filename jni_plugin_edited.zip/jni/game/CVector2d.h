#pragma once

class CVector2D
{
public:
	float x, y;
public:
	CVector2D() { x = y = 0; };
	CVector2D(float f) { x = y = f; };
    CVector2D(float X, float Y) : x(X), y(Y) {}; 
};