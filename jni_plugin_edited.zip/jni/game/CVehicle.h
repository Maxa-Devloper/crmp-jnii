#pragma once

enum eVehicleType {
    VEHICLE_TYPE_CAR, 
    VEHICLE_TYPE_BOAT, 
    VEHICLE_TYPE_TRAIN, 
    VEHICLE_TYPE_HELI, 
    VEHICLE_TYPE_PLANE, 
    VEHICLE_TYPE_BIKE, 
    VEHICLE_TYPE_TRUCK, 
    VEHICLE_TYPE_TRAILER, 
    VEHICLE_TYPE_QUAD, 
    VEHICLE_TYPE_BMX,
    NUM_VEHICLE_TYPES
};

enum eCarLock {
	CARLOCK_NOT_USED,
	CARLOCK_UNLOCKED,
	CARLOCK_LOCKED,
	CARLOCK_LOCKOUT_PLAYER_ONLY,
	CARLOCK_LOCKED_PLAYER_INSIDE,
	CARLOCK_LOCKED_INITIALLY,
	CARLOCK_FORCE_SHUT_DOORS,
	CARLOCK_LOCKED_BUT_CAN_BE_DAMAGED
};

struct tGear
{
	float fMaxVelocity;
	float fShiftUpVelocity;
	float fShiftDownVelocity;
};

class cTransmission
{
public:
	// Gear 0 is reverse, 1-5 are forward
	tGear Gears[6];
	char nDriveType;
	char nEngineType;
	int8 nNumberOfGears;
	uint8 Flags;
	float fEngineAcceleration;
	float fEngineInertia;
	float fMaxVelocity;
	float fMaxCruiseVelocity;
	float fMaxReverseVelocity;
	float fCurVelocity;
};

struct tHandlingData
{
    char szName[24];
	int nIdentifier;
	float fMass;
	float fInvMass;
	float fTurnMass;
	float fDragMult;
	CVector CentreOfMass;
	int8 nPercentSubmerged;
	float fBuoyancy;
	float fTractionMultiplier;
	cTransmission Transmission;
	float fBrakeDeceleration;
	float fBrakeBias;
	int8 bABS;
	float fSteeringLock;
	float fTractionLoss;
	float fTractionBias;
	float fUnused;
	float fSuspensionForceLevel;
	float fSuspensionDampingLevel;
	float fSuspensionUpperLimit;
	float fSuspensionLowerLimit;
	float fSuspensionBias;
	float fSuspensionAntidiveMultiplier;
	float fCollisionDamageMultiplier;
	uint32 ModelFlags;
	uint32 HandlingFlags;
	float fSeatOffsetDistance;
	int32 nMonetaryValue;
	int8 FrontLights;
	int8 RearLights;
	float fHighLightsAngle;
};