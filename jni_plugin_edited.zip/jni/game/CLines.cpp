#include "../main.h"
#include "CLines.h"


void CLines::RenderLineWithClipping(float x1, float y1, float z1, float x2, float y2, float z2, uint32 c1, uint32 c2)
{
    return (( void (*)(float, float, float, float, float, float, uint32, uint32))(gameAddr + 0x48B7C8 + 1))(x1, y1, z1, x2, y2, z2, c1, c2);
}