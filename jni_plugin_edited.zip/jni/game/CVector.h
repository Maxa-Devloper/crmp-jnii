#ifndef _VECTOR_H_
#define _VECTOR_H_

#include <cmath>

class CVector
{
public:
	float X, Y, Z;
public:
	CVector()
	{
		X = Y = Z = 0.0f;
	}

	CVector(float f)
	{
		X = Y = Z = f;
	}
	
	CVector(float x, float y, float z)
	{
		X = x;
		Y = y;
		Z = z;
	}

	float SquaredMagnitude()
	{
	    return X * X + Y * Y + Z * Z;
	}
	
	float Magnitude()
	{
	    return std::sqrt(this->SquaredMagnitude());
	}

	void Normalize()
	{
	    float mag = Magnitude();
	    if (mag > 0)
	    {
	        X /= mag;
	        Y /= mag;
	        Z /= mag;
	    }
	}

	CVector operator-() const {
		return CVector(-X, -Y, -Z);
	}

	const CVector &operator+=(CVector const &right) {
		X += right.X;
		Y += right.Y;
		Z += right.Z;
		return *this;
	}

	const CVector &operator-=(CVector const &right) {
		X -= right.X;
		Y -= right.Y;
		Z -= right.Z;
		return *this;
	}

	const CVector &operator*=(float right) {
		X *= right;
		Y *= right;
		Z *= right;
		return *this;
	}

	const CVector &operator/=(float right) {
		X /= right;
		Y /= right;
		Z /= right;
		return *this;
	}

	const bool operator==(CVector const &right) const {
		return X == right.X && Y == right.Y && Z == right.Z;
	}

	const bool operator!=(CVector const &right) const {
		return X != right.X || Y != right.Y || Z != right.Z;
	}

	bool IsZero(void) const { return X == 0.0f && Y == 0.0f && Z == 0.0f; }
};

inline CVector operator+(const CVector &left, const CVector &right)
{
	return CVector(left.X + right.X, left.Y + right.Y, left.Z + right.Z);
}

inline CVector operator-(const CVector &left, const CVector &right)
{
	return CVector(left.X - right.X, left.Y - right.Y, left.Z - right.Z);
}

inline CVector operator*(const CVector &left, float right)
{
	return CVector(left.X * right, left.Y * right, left.Z * right);
}

inline CVector operator*(float left, const CVector &right)
{
	return CVector(left * right.X, left * right.Y, left * right.Z);
}

inline CVector operator/(const CVector &left, float right)
{
	return CVector(left.X / right, left.Y / right, left.Z / right);
}

#endif /* _VECTOR_H_ */